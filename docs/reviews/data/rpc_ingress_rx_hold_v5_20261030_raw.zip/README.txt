RPC ingress RX-hold v5 原始材料

本归档是在当前 release-readiness 分支 `006af2aec502d59a4fbcdf7c0f9e212795548618` / dev.182 上进行的单轮诊断，不是性能验收。原始负载固定为明文 40k 计划速率、250ms 到达窗口、每档 10,000 个计划到达、16 个发生器、每发生器窗口/容量 64、3,000ms 期限、服务端延时 0；只跑 small/default/large 三个公开 profile。三档均保留发生器迟到/丢弃和服务器压力信号，全部 dirty。

探针以 v4 的完整帧、epoll、最近 hold/pause 插桩为基础，额外逐次记录每个连接 rx_held 0→1 与 1→0 区间。成功解除 hold 后，在同一 owner 调用中使用 ioctl(FIONREAD) 只读采样套接字排队字节，并记录解析器状态、header_have、payload_have；连接关闭时仍未结束的区间标 complete=0。每 Reactor 最多保留 131072 条，饱和只增加 overflow，不终止试验。FIONREAD 不消费数据。该插桩增加了内存和时钟/ioctl 开销，不能用于性能对照。

`probe-v5.patch` 是从干净 HEAD 生成的完整临时补丁；包含 v4 原始观察点和本轮区间记录。`analyze_hold_intervals.py` 将每个客户端 DATA/TX 请求 MESSAGE 与服务器 DATA/RX 按反向 TCP 端口、stream_id、message_id 关联。单 unary 请求的记录顺序为 OPEN=1、MESSAGE=2、HALF_CLOSE=3；窗口只采用 MESSAGE 帧。又用正文 PID/序号及 client stream_map 确认每条成功 server 业务 MESSAGE 的 stream；三档均 100% 关联。FIONREAD 是连接级快照，能证明采样瞬间有待收字节，但不标识其中具体 stream；区间覆盖是时间关联，不能单独声称特定 RPC 字节被 hold 阻塞。

分析结果：small 1889 个成功业务请求中 832 个（44.0%）的 TX begin→server recv begin 窗口与 hold 重叠；default 为 1962 中 683 个（34.8%）；large 为 1767 中 391 个（22.1%）。每个重叠窗口都包含一次正 FIONREAD 的 hold 解除；且客户端完成该 MESSAGE 帧的 send 调用先于解除的比例分别为 44.0%、34.7%、22.1%。三档完整 hold 解除中有 279/280、205/207、70/70 次采到待收数据，且这些正值样本的 parser 都在干净 HEADER 边界。尽管有一部分窗口的条件 P50 hold 覆盖为 26.7%–40.2%，对所有成功请求计算的覆盖比例 P50 都是 0%，说明 hold 能解释一部分等待，不能解释整体长尾。

所有 profile 原始 stdout/stderr、repeatability JSONL、执行元数据、完整补丁、分析器和 JSON 汇总均在此归档。SHA-256/字节数见 INDEX.json。环境临时路径都指向隔离工作树的 `build/test-tmp`，没有在 `/tmp` 写入测试文件、日志、构建产物或缓存。
