"""为本次诊断保存原文件并加入可撤销的 CONTROL TX 计数。"""
from pathlib import Path
import hashlib
import json
import subprocess

root = Path.cwd()
out = root / 'build/performance-20261029/control-tx-probe-v182'
out.mkdir(exist_ok=False)
path = root / 'src/execution/reactor.c'
before = path.read_bytes()
(out / 'reactor.c.original').write_bytes(before)
source = before.decode()

def replace(old, new, count=1):
    global source
    assert source.count(old) == count, (old[:100], source.count(old), count)
    source = source.replace(old, new)

replace('#include <limits.h>', '#include <limits.h>\n#include <inttypes.h>\n#include <stdio.h>')
replace('static _Thread_local struct tr_reactor *tr_current_reactor_owner;',
        'static _Thread_local struct tr_reactor *tr_current_reactor_owner;\n'
        'static _Thread_local unsigned tr_control_probe_phase;')
replace('struct tr_tx_pool {\n', '''struct tr_tx_probe_sample {
	unsigned phase;
	uint16_t type;
	uint32_t slot;
	uint32_t command_count;
	uint32_t ready_connections;
	uint32_t waiting_connections;
	uint32_t queued_control[32];
	uint32_t queued_data;
};

struct tr_tx_pool {
	uint64_t probe_acquired[32][7];
	uint64_t probe_failed[32][7];
	uint64_t probe_released[32];
''')
replace('\tstruct tr_tx_pool control_tx_pool;', '''	struct tr_tx_pool control_tx_pool;
	struct tr_tx_probe_sample probe_samples[8];
	unsigned probe_sample_count;
	unsigned char probe_sample_seen[32][7];''')
replace('static int tr_tx_pool_init(', '''static void tr_tx_probe_sample(struct tr_reactor *reactor,
                               uint16_t type, uint32_t slot)
{
	struct tr_tx_probe_sample *sample;
	if (!tr_reactor_is_owner_thread(reactor) ||
	    reactor->probe_sample_count == 8U ||
	    reactor->probe_sample_seen[type][tr_control_probe_phase])
		return;
	reactor->probe_sample_seen[type][tr_control_probe_phase] = 1U;
	sample = &reactor->probe_samples[reactor->probe_sample_count++];
	sample->phase = tr_control_probe_phase;
	sample->type = type;
	sample->slot = slot;
	pthread_mutex_lock(&reactor->commands.lock);
	sample->command_count = reactor->commands.count;
	pthread_mutex_unlock(&reactor->commands.lock);
	for (struct tr_connection *connection = reactor->tx_ready_head;
	     connection; connection = connection->tx_ready_next)
		sample->ready_connections++;
	for (uint32_t i = 0U; i < reactor->config.max_connections; ++i) {
		struct tr_connection *connection = &reactor->connections[i];
		if (connection->state != TR_CONN_ACTIVE)
			continue;
		if (connection->tx_wait_writable ||
		    (connection->byte_endpoint &&
		     connection->byte_endpoint->write_wait))
			sample->waiting_connections++;
		for (struct tr_tx_item *item = connection->tx_head;
		     item; item = item->next) {
			if (item->owner_pool == &reactor->control_tx_pool)
				sample->queued_control[item->type]++;
			else if (item->owner_pool == &reactor->tx_pool)
				sample->queued_data++;
		}
	}
}

static void tr_tx_probe_report(struct tr_reactor *reactor)
{
	for (unsigned i = 0; i < reactor->probe_sample_count; ++i) {
		struct tr_tx_probe_sample *s = &reactor->probe_samples[i];
		fprintf(stderr, "{\\"type\\":\\"control_tx_probe_sample\\","
		        "\\"phase\\":%u,\\"frame_type\\":%u,\\"slot\\":%u,"
		        "\\"command_count\\":%u,\\"ready_connections\\":%u,"
		        "\\"waiting_connections\\":%u,\\"queued_data\\":%u,"
		        "\\"queued_control\\":[", s->phase, s->type, s->slot,
		        s->command_count, s->ready_connections,
		        s->waiting_connections, s->queued_data);
		for (unsigned j = 0; j < 32U; ++j)
			fprintf(stderr, "%s%u", j ? "," : "", s->queued_control[j]);
		fprintf(stderr, "]}\\n");
	}
}

static int tr_tx_pool_init(''')
replace('static void tr_tx_pool_destroy(struct tr_tx_pool *pool)\n{', '''static void tr_tx_pool_destroy(struct tr_tx_pool *pool)
{''')
replace('\tfree(pool->items);\n\tpool->items = NULL;', '''	for (unsigned type = 1U; type < 32U; ++type) {
		for (unsigned phase = 0U; phase < 7U; ++phase) {
			if (!pool->probe_acquired[type][phase] &&
			    !pool->probe_failed[type][phase])
				continue;
			fprintf(stderr, "{\\"type\\":\\"tx_pool_probe\\","
			        "\\"capacity\\":%u,\\"free_final\\":%u,"
			        "\\"frame_type\\":%u,\\"phase\\":%u,"
			        "\\"acquired\\":%" PRIu64 ",\\"failed\\":%" PRIu64
			        ",\\"released_type_total\\":%" PRIu64 "}\\n",
			        pool->capacity, pool->free_count, type, phase,
			        pool->probe_acquired[type][phase],
			        pool->probe_failed[type][phase],
			        pool->probe_released[type]);
		}
	}
	free(pool->items);
	pool->items = NULL;''')
replace('tr_tx_pool_acquire(struct tr_tx_pool *pool)',
        'tr_tx_pool_acquire(struct tr_tx_pool *pool, uint16_t type)')
replace('\t\tpool->free_count--;',
        '\t\tpool->free_count--;\n\t\tpool->probe_acquired[type][tr_control_probe_phase]++;')
replace('\t\tpool->exhausted_events++;',
        '\t\tpool->exhausted_events++;\n\t\tpool->probe_failed[type][tr_control_probe_phase]++;')
replace('\titem->next = pool->free_list;\n\tpool->free_list = item;',
        '\tpool->probe_released[item->type]++;\n'
        '\titem->next = pool->free_list;\n\tpool->free_list = item;')
replace('\t\t\t\t\t  &reactor->control_tx_pool);',
        '\t\t\t\t\t  &reactor->control_tx_pool, type);')
replace('\tif (!item) {\n\t\tif (pool_exhausted)',
        '\tif (!item) {\n\t\tif (type != TR_FRAME_DATA)\n'
        '\t\t\ttr_tx_probe_sample(reactor, type, connection.slot);\n'
        '\t\tif (pool_exhausted)')
replace('\t\ttr_tx_pool_destroy(&reactor->tx_pool);',
        '\t\ttr_tx_pool_destroy(&reactor->tx_pool);')
replace('\n\ttr_tx_pool_destroy(&reactor->tx_pool);',
        '\n\ttr_tx_probe_report(reactor);\n\ttr_tx_pool_destroy(&reactor->tx_pool);')

start = source.index('static void *tr_reactor_thread_main(void *arg)')
end = source.index('\nstatic ', start + 10)
part = source[start:end]
for prefix, phase in [
        ('\t\tcommands_pending = tr_process_commands', 1),
        ('\t\tcompletions_pending = tr_process_completions', 2),
        ('\t\ttimers_pending = tr_process_timers', 3),
        ('\t\ttr_run_tx_capacity_ready', 4),
        ('\t\ttr_run_rx_ready', 5),
        ('\t\ttr_run_tx_ready', 6),
        ('\t\t(void)tr_process_timers', 3),
        ('\t\t\t\t(void)tr_process_completions', 2),
        ('\t\tturn.polled = 1;', 0)]:
    assert prefix in part, prefix
    indent = prefix[:len(prefix) - len(prefix.lstrip())]
    part = part.replace(prefix, indent + f'tr_control_probe_phase = {phase}U;\n' + prefix)
part = part.replace('\t\tfor (i = 0; i < count; ++i) {',
                    '\t\tfor (i = 0; i < count; ++i) {\n'
                    '\t\t\ttr_control_probe_phase = 0U;')
source = source[:start] + part + source[end:]
path.write_text(source)
patch = subprocess.check_output(['git', 'diff', '--', str(path)], cwd=root)
(out / 'probe.json').write_text(json.dumps({
    'base': subprocess.check_output(['git','rev-parse','HEAD'], text=True).strip(),
    'original_sha256': hashlib.sha256(before).hexdigest(),
    'instrumented_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
    'patch': patch.decode(),
    'phases': ['outside', 'commands', 'completions', 'timers', 'capacity_ready', 'rx', 'tx'],
    'limit_samples_per_reactor': 8,
}, ensure_ascii=False, indent=2) + '\n')
print(out)
