"""归档三组临时诊断的原始记录、身份与未通过容量判定。"""
import ast
import csv
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import zipfile

root=Path.cwd()
build=root/'build/performance-20261029'
data=root/'docs/reviews/data'
experiment=root/'docs/reviews/experiments/control_tx_admission_20261030'
experiment.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(root/'bench'))
from run_rpc_scalability import clean_result,exact_wall_signals

def sha(body):
    return hashlib.sha256(body).hexdigest()

names=('control-tx-probe-v182','control-tx-interleave-probe-v182',
       'rpc-admission-probe-v182')
stages=('pool_baseline','pool_interleave_candidate','admission_baseline')
rows=[]
probes=[]
raw={}
balanced_processes=0
pool_processes=0
baseline_samples=[]
for name,stage in zip(names,stages):
    out=build/name
    probe=json.loads((out/'probe.json').read_text())
    assert sha((out/'bench_rpc.probe').read_bytes())==probe['binary_sha256']
    assert probe['source_restored']
    probe['stage']=stage
    probe['source_path']='bench/bench_rpc.c' if stage=='admission_baseline' else 'src/execution/reactor.c'
    assert sha((root/probe['source_path']).read_bytes())==probe['original_sha256']
    probes.append(probe)
    for path in sorted(out.rglob('*')):
        if not path.is_file() or path.name=='bench_rpc.probe' or path.suffix=='.original':
            continue
        raw[str(path.relative_to(build))]=path.read_bytes()
    for mode in ('plain','tls-zstd'):
        records=list(map(json.loads,(out/f'{mode}.jsonl').read_text().splitlines()))
        assert records[0]['binary_sha256']==probe['binary_sha256']
        cases=[r for r in records if r['type']=='repeatability_case']
        assert len(cases)==3
        for case in cases:
            c=case['case'];client=case['client'];server=case['server_exit']
            assert (c['rate_rps'],c['requests'],c['generators'],
                    c['generator_window'],c['generator_capacity'])==(40000,10000,16,64,64)
            assert case['wall_signals']==exact_wall_signals(case)
            assert not clean_result(case)
            assert server['control_tx_pool_capacity']==128
            assert case['server']['compression']==('zstd' if mode=='tls-zstd' else 'none')
            assert case['server']['tls_enabled']==int(mode=='tls-zstd')
            directory=out/f'{mode}-logs'/f"t1-{case['public_profile']}-40000rps"
            failures=[]
            samples=[]
            if stage!='admission_baseline':
                for log in sorted(directory.glob('*.stderr')):
                    records=list(map(json.loads,log.read_text().splitlines()))
                    groups={}
                    for record in records:
                        if record['type']=='control_tx_probe_sample':
                            if log.name=='server.stderr':
                                samples.append(record)
                            continue
                        assert record['type']=='tx_pool_probe'
                        assert record['free_final']==record['capacity']
                        key=(record['capacity'],record['frame_type'])
                        group=groups.setdefault(key,[0,record['released_type_total']])
                        assert group[1]==record['released_type_total']
                        group[0]+=record['acquired']
                        if log.name=='server.stderr' and record['failed']:
                            failures.append(record)
                    assert groups and all(a==b for a,b in groups.values())
                    balanced_processes+=1
                pool_processes+=17
                assert sum(x['failed'] for x in failures if x['frame_type']!=1)==server['control_tx_pool_exhausted_events']
            if stage=='pool_baseline':
                assert all(sum(s['queued_control'])==128 and not s['waiting_connections']
                           and not s['command_count'] for s in samples)
                baseline_samples.extend(samples)
            row=dict(stage=stage,mode=mode,profile=case['public_profile'],
                     offered=client['offered'],attempted=client['attempted'],
                     accepted=client['accepted'],completed=client['completed'],
                     ok=client['ok'],dropped=client['scheduler_dropped'],
                     submit_again=client['submit_again'],deadlines=client['deadlines'],
                     resource_exhausted=client['resource_exhausted'],
                     late_p99_us=client['scheduler_late_p99_us'],
                     control_tx_exhausted=server['control_tx_pool_exhausted_events'],
                     data_tx_exhausted=server['tx_pool_exhausted_events'],
                     clean=False,wall_signals=case['wall_signals'],
                     server_pool_failures=failures,first_failure_samples=samples)
            rows.append(row)
assert len(rows)==18 and balanced_processes==pool_processes==204
assert len(baseline_samples)==23

admission=json.loads((build/names[2]/'admission_summary.json').read_text())
assert len(admission)==6
assert sum(r['dropped'] for r in admission)==49110
assert all(r['drops_not_reconstructed_as_64_outstanding']==0 for r in admission)
helpers=('instrument_control_tx.py','instrument_rpc_admission.py',
         'run_control_tx_probe.py','run_control_tx_interleave_probe.py',
         'run_rpc_admission_probe.py','archive_control_tx_probe.py')
for name in helpers:
    body=(build/name).read_bytes()
    ast.parse(body)
    raw['helpers/'+name]=body
checks=json.loads((build/'checks-a3077c32d449190eeb86b0cfb1b22918312da1f4.json').read_text())
assert checks['total_count']==len(checks['check_runs'])==13
assert all(r['head_sha']==probes[0]['base'] and r['conclusion']=='success' for r in checks['check_runs'])
raw['checks-a3077c3.json']=json.dumps(checks,indent=2).encode()+b'\n'
raw['xmake.conf']=(root/'.xmake/linux/x86_64/xmake.conf').read_bytes()
subprocess.run(['git','diff','--exit-code','--','src','include','bench','xmake.lua'],check=True)
production=bytes.fromhex('55d1c4b990f1878f7999017960c2c6cf5443fdf998be9ece389c5fa946bd137e').hex()
assert sha((root/'build/linux/x86_64/release/bench_rpc').read_bytes())==production
index={name:dict(bytes=len(body),sha256=sha(body)) for name,body in raw.items()}
target=data/'control_tx_admission_20261030_raw.zip'
with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,body in sorted(raw.items()):
        assert not body.startswith(b'\x7fELF')
        assert not any(line.startswith(b'-----BEGIN ') and b'PRIVATE KEY-----' in line
                       for line in body.splitlines())
        archive.writestr(name,body)
    archive.writestr('INDEX.json',json.dumps(index,indent=2)+'\n')
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
    assert set(archive.namelist())==set(index)|{'INDEX.json'}
    for name,meta in index.items():
        body=archive.read(name)
        assert len(body)==meta['bytes'] and sha(body)==meta['sha256']

(experiment/'probes.json').write_text(json.dumps(probes,ensure_ascii=False,indent=2)+'\n')
summary=dict(base=probes[0]['base'],runtime_source='0d81342e85739bcd8ff0253bdbcd894c602696c0',
             runtime_version='2.0.0-dev.182',production_unchanged=True,
             restored_benchmark_sha256=production,cases=rows,
             baseline_failure_samples=len(baseline_samples),balanced_processes=balanced_processes,
             admission=admission,archive=dict(path=target.name,bytes=target.stat().st_size,
               sha256=sha(target.read_bytes()),raw_members=len(raw)),
             clean_cases=0,total_cases=len(rows),candidate_adopted=False,
             ci_base_head=probes[0]['base'],ci_base_success=13,
             ci_archive_head='pending')
(data/'control_tx_admission_20261030_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
fields=('stage','mode','profile','offered','attempted','accepted','completed','ok','dropped',
        'submit_again','deadlines','resource_exhausted','late_p99_us',
        'control_tx_exhausted','data_tx_exhausted','clean','wall_signals')
with (data/'control_tx_admission_20261030_cases.csv').open('w',newline='') as handle:
    writer=csv.DictWriter(handle,fieldnames=fields,lineterminator='\n')
    writer.writeheader()
    for row in rows:
        writer.writerow({k:'|'.join(row[k]) if k=='wall_signals' else row[k] for k in fields})
print(json.dumps(dict(cases=len(rows),clean=0,balanced_processes=balanced_processes,
                     baseline_failure_samples=len(baseline_samples),archive=summary['archive']),indent=2))
