"""仅给临时基准加入唤醒、锁取得和同步提交返回时间。"""
from pathlib import Path
import hashlib
import json
import subprocess

root=Path.cwd()
out=root/'build/performance-20261029/rpc-admission-probe-v182'
out.mkdir(exist_ok=False)
path=root/'bench/bench_rpc.c'
before=path.read_bytes()
(out/'bench_rpc.c.original').write_bytes(before)
source=before.decode()

def replace(old,new):
    global source
    assert source.count(old)==1,(old[:80],source.count(old))
    source=source.replace(old,new)

replace('\tuint64_t scheduled_ns, start_ns, submit_ns, end_ns;',
        '\tuint64_t scheduled_ns, start_ns, submit_ns, end_ns;\n'
        '\tuint64_t probe_lock_ns, probe_return_ns;')
replace('static int open_phase(struct client_run *run, const struct options *o)', '''static uint64_t probe_thread_cpu_ns(void)
{
	struct timespec value;
	check(clock_gettime(CLOCK_THREAD_CPUTIME_ID, &value), "probe thread CPU");
	return (uint64_t)value.tv_sec * UINT64_C(1000000000) +
	       (uint64_t)value.tv_nsec;
}

static int open_phase(struct client_run *run, const struct options *o)''')
replace('\tuint64_t begin, horizon, guard, end;',
        '\tuint64_t begin, horizon, guard, end;\n'
        '\tuint64_t probe_cpu_begin = probe_thread_cpu_ns();')
replace('\t\tcheck(pthread_mutex_lock(&run->lock), "open lock");',
        '\t\tcheck(pthread_mutex_lock(&run->lock), "open lock");\n'
        '\t\ts->probe_lock_ns = now_ns();')
replace('\t\tcheck(pthread_mutex_lock(&run->lock), "open submit lock");',
        '\t\ts->probe_return_ns = now_ns();\n'
        '\t\tcheck(pthread_mutex_lock(&run->lock), "open submit lock");')
replace('\treport_open_phase(samples, o->requests, o->rate_rps, begin, horizon,', '''	fprintf(stderr, "{\\"type\\":\\"rpc_admission_probe\\","
	        "\\"main_thread_cpu_ns\\":%" PRIu64 ",\\"begin_ns\\":%" PRIu64
	        ",\\"end_ns\\":%" PRIu64 ",\\"columns\\":[\\"scheduled_ns\\","
	        "\\"wake_ns\\",\\"lock_acquired_ns\\",\\"submit_ns\\","
	        "\\"api_return_ns\\",\\"terminal_ns\\",\\"submit_status\\","
	        "\\"scheduler_dropped\\"],\\"samples\\":[",
	        probe_thread_cpu_ns() - probe_cpu_begin, begin, end);
	for (uint32_t sample = 0U; sample < o->requests; ++sample) {
		const struct sample *s = &samples[sample];
		fprintf(stderr, "%s[%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%" PRIu64
		        ",%" PRIu64 ",%" PRIu64 ",%d,%d]", sample ? "," : "",
		        s->scheduled_ns, s->start_ns, s->probe_lock_ns,
		        s->submit_ns, s->probe_return_ns, s->end_ns,
		        s->submit_status, s->scheduler_dropped);
	}
	fprintf(stderr, "]}\\n");
	report_open_phase(samples, o->requests, o->rate_rps, begin, horizon,''')
path.write_text(source)
(out/'probe.json').write_text(json.dumps({
    'base':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    'original_sha256':hashlib.sha256(before).hexdigest(),
    'instrumented_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
    'patch':subprocess.check_output(['git','diff','--','bench/bench_rpc.c']).decode(),
    'runtime_source_unchanged':True,
},ensure_ascii=False,indent=2)+'\n')
print(out)
