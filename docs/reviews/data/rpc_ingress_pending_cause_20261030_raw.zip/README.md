# RPC pending hold 来源探针

基线为 dev.182 / `006af2aec502d59a4fbcdf7c0f9e212795548618`。此临时诊断只标记
初始 WINDOW_UPDATE / STREAM_REFUSED 背压区间、后续进度调用、发送尝试及解除来源；
不改产品行为，不采样 FIONREAD，不作为 40k 性能验收。完整执行参数见 `execution.json`，
逐事件记录见 `repeatability-logs/`，`INDEX.json` 登记归档成员 SHA-256 与字节数。

本次三个 profile 均为 dirty。结果只证明这轮样本中多数 RX hold 来自 pending OPEN，
并由 CONTROL_TX_READY 路径解除；它不能说明该 hold 是整体 40k 长尾的唯一根因。
