"""归档分层时间线、撤回的帧配额候选与有效/失败的 Callgrind 驱动。"""
from pathlib import Path
import ast,csv,hashlib,json,subprocess,sys,zipfile
root=Path.cwd();build=root/'build/performance-20261029';data=root/'docs/reviews/data'
experiment=root/'docs/reviews/experiments/rpc_progress_trace_20261030'
experiment.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(root/'bench'))
from run_rpc_scalability import clean_result,exact_wall_signals
def sha(b):return hashlib.sha256(b).hexdigest()
names=('rpc-progress-cpu-probe-v182','rpc-unary-stage-probe-v182',
       'rpc-client-credit-probe-v182','rpc-frame-path-probe-v182',
       'rpc-rx-frame-budget-probe-v182')
stages=('progress_cpu','unary_stages','client_credit','frame_path','rx_frame_candidate')
raw={};probes=[];cases=[];analyses={}
for name,stage in zip(names,stages):
    out=build/name;probe=json.loads((out/'probe.json').read_text())
    assert probe['source_restored']
    assert sha((out/'bench_rpc.probe').read_bytes())==probe['binary_sha256']
    files=probe.get('files') or {probe['source_path']:{
        'original_sha256':probe['original_sha256'],
        'instrumented_sha256':probe['instrumented_sha256']}}
    for path,meta in files.items():assert sha((root/path).read_bytes())==meta['original_sha256']
    probe['stage']=stage;probe['files']=files;probes.append(probe)
    analyses[stage]=json.loads((out/'summary.json').read_text())
    for path in sorted(out.rglob('*')):
        if not path.is_file() or path.suffix=='.original' or path.name=='bench_rpc.probe':continue
        raw[str(path.relative_to(build))]=path.read_bytes()
    rows=list(map(json.loads,(out/'plain.jsonl').read_text().splitlines()))
    assert rows[0]['binary_sha256']==probe['binary_sha256']
    group=[r for r in rows if r['type']=='repeatability_case'];assert len(group)==3
    for row in group:
        c=row['case'];client=row['client'];server=row['server_exit']
        assert (c['rate_rps'],c['requests'],c['generators'],c['generator_window'],c['generator_capacity'])==(40000,10000,16,64,64)
        assert c['timeout_ms']==3000 and c['slow_ms']==0
        assert not c['tls'] and c['compression']=='none'
        assert row['wall_signals']==exact_wall_signals(row) and not clean_result(row)
        assert server['rpc_tasks_queued']==server['rpc_tasks_running']==0
        assert server['control_tx_pool_capacity']==128
        cases.append(dict(stage=stage,profile=row['public_profile'],
              offered=client['offered'],attempted=client['attempted'],accepted=client['accepted'],
              completed=client['completed'],ok=client['ok'],dropped=client['scheduler_dropped'],
              submit_again=client['submit_again'],submit_errors=client['submit_errors'],
              invalid_responses=client['invalid_responses'],deadlines=client['deadlines'],
              resource_exhausted=client['resource_exhausted'],
              control_tx_exhausted=server['control_tx_pool_exhausted_events'],
              data_tx_exhausted=server['tx_pool_exhausted_events'],
              late_p99_us=client['scheduler_late_p99_us'],
              clean=False,wall_signals=row['wall_signals']))
assert len(cases)==15
assert all(r['tcp_nodelay']==[1] for key in ('frame_path','rx_frame_candidate') for r in analyses[key])
assert (build/names[3]/'summary.json').read_bytes()==(build/names[3]/'summary.first.json').read_bytes()
for name in ('rpc-callgrind-v182','rpc-callgrind-v182-verified'):
    for path in sorted((build/name).rglob('*')):
        if path.is_file():raw[str(path.relative_to(build))]=path.read_bytes()
profile=json.loads((build/'rpc-callgrind-v182-verified/execution.json').read_text())
assert profile['client_exit_code']==profile['server_exit_code']==0
server_lines=(build/'rpc-callgrind-v182-verified/server.jsonl').read_text().splitlines()
server_final=json.loads(server_lines[-1]);assert server_final['rpc_calls_started']==server_final['rpc_calls_finished']==288
owner=build/'rpc-callgrind-v182-verified/callgrind.3585999-02'
assert 'summary: 18796047\n' in owner.read_text()
failure=dict(stage='first_callgrind_driver',error='TypeError: validate_phase() takes 3 positional arguments but 4 were given',
             client_exit_code=0,server_normal_drain_validated=False,
             cleanup='finally 调用原 stop_owned；未记录 Server 退出码，不推断正常排空',
             first_driver_sha256=sha((build/'rpc-callgrind-v182/run_rpc_callgrind.first.py').read_bytes()),
             correction='使用 clean=True 关键字参数，在全新目录重跑；两端退出 0，288 项排空')
raw['callgrind-first-validation-failure.json']=json.dumps(failure,ensure_ascii=False,indent=2).encode()+b'\n'
helpers=('instrument_rpc_progress_cpu.py','run_rpc_progress_cpu_probe.py',
         'instrument_rpc_unary_stages.py','run_rpc_unary_stage_probe.py','analyze_rpc_unary_stages.py',
         'instrument_rpc_client_credit.py','run_rpc_client_credit_probe.py','analyze_rpc_client_credit.py',
         'instrument_rpc_frame_path.py','run_rpc_frame_path_probe.py','analyze_rpc_frame_path.py',
         'run_rpc_rx_frame_budget_probe.py','analyze_rpc_rx_frame_budget.py',
         'run_rpc_callgrind.py','archive_rpc_progress_trace.py')
for name in helpers:
    body=(build/name).read_bytes();ast.parse(body);raw['helpers/'+name]=body
checks=json.loads((build/'checks-3ca47d15c9ac571882d2b61a522e73fb315bfb72.json').read_text())
assert len(checks['check_runs'])==13 and all(r['conclusion']=='success' and r['head_sha']==probes[0]['base'] for r in checks['check_runs'])
raw['checks-3ca47d1.json']=json.dumps(checks,indent=2).encode()+b'\n'
raw['xmake.conf']=(root/'.xmake/linux/x86_64/xmake.conf').read_bytes()
index={name:dict(bytes=len(body),sha256=sha(body)) for name,body in raw.items()}
target=data/'rpc_progress_trace_20261030_raw.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,body in sorted(raw.items()):
        assert not body.startswith(b'\x7fELF')
        assert not any(line.startswith(b'-----BEGIN ') and b'PRIVATE KEY-----' in line for line in body.splitlines())
        z.writestr(name,body)
    z.writestr('INDEX.json',json.dumps(index,indent=2)+'\n')
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None and set(z.namelist())==set(index)|{'INDEX.json'}
    for name,meta in index.items():
        body=z.read(name);assert len(body)==meta['bytes'] and sha(body)==meta['sha256']
production='55d1c4b990f1878f7999017960c2c6cf5443fdf998be9ece389c5fa946bd137e'
assert sha((root/'build/linux/x86_64/release/bench_rpc').read_bytes())==production
subprocess.run(['git','diff','--exit-code','--','src','include','bench','xmake.lua'],check=True)
bench_source=(root/'bench/bench_rpc.c').read_text()
assert 'limits->max_calls = 2U * o->capacity;' in bench_source
assert 'limits->max_streams = 2U * o->capacity;' in bench_source
summary=dict(base=probes[0]['base'],runtime_source='0d81342e85739bcd8ff0253bdbcd894c602696c0',
             version='2.0.0-dev.182',production_unchanged=True,production_benchmark_sha256=production,
             cases=cases,analyses=analyses,total_cases=15,clean_cases=0,candidate_adopted=False,
             capacity_interpretation=dict(bench_parameters=[32,128,256],max_calls=[64,256,512],
                 max_streams=[64,256,512],source='bench/bench_rpc.c:configure_limits'),
             totals={key:sum(r[key] for r in cases) for key in ('offered','attempted','accepted','completed','ok','dropped','submit_again','submit_errors','invalid_responses','deadlines','resource_exhausted')},
             callgrind=dict(owner_instructions=18796047,server_calls=288,client_requests=256,warmup=32,
                 tool='Valgrind 3.25.1',collection='tr_reactor_thread_main',
                 dispatch_self_instructions=3286606,endpoint_pump_self_instructions=1836884,
                 deferred_self_instructions=1444950,first_driver_failure=failure),
             archive=dict(path=target.name,bytes=target.stat().st_size,sha256=sha(target.read_bytes()),raw_members=len(raw)))
(experiment/'probes.json').write_text(json.dumps(probes,ensure_ascii=False,indent=2)+'\n')
(data/'rpc_progress_trace_20261030_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
with (data/'rpc_progress_trace_20261030_cases.csv').open('w',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(cases[0]),lineterminator='\n');writer.writeheader()
    for r in cases:writer.writerow(dict(r,wall_signals='|'.join(r['wall_signals'])))
print(json.dumps(dict(totals=summary['totals'],archive=summary['archive'],owner_instructions=18796047),indent=2))
