"""仅在临时基准中关联调用入口、服务端业务消息和客户端回调时间。"""
from pathlib import Path
import hashlib,json,subprocess
root=Path.cwd();out=root/'build/performance-20261029/rpc-unary-stage-probe-v182'
out.mkdir(exist_ok=False)
path=root/'bench/bench_rpc.c';before=path.read_bytes()
(out/'bench_rpc.c.original').write_bytes(before)
previous=json.loads((root/'build/performance-20261029/rpc-admission-probe-v182/probe.json').read_text())
assert hashlib.sha256(before).hexdigest()==previous['original_sha256']
subprocess.run(['git','apply','--check','-'],input=previous['patch'].encode(),check=True)
subprocess.run(['git','apply','-'],input=previous['patch'].encode(),check=True)
s=path.read_text()
def replace(old,new,count=1):
    global s
    assert s.count(old)==count,(old[:80],s.count(old))
    s=s.replace(old,new)
replace('\tuint64_t probe_lock_ns, probe_return_ns;',
        '\tuint64_t probe_lock_ns, probe_return_ns, probe_message_ns;')
replace('static enum tr_rpc_status echo_v2(', 'static enum tr_rpc_status echo_v2_impl(')
replace('static int run_server(const struct options *o)', '''struct tr_unary_probe_event {
	uint64_t sequence, begin_ns, end_ns;
	int status;
};
static struct tr_unary_probe_event tr_unary_probe_events[32768];
static atomic_uint tr_unary_probe_count;
static enum tr_rpc_status echo_v2(struct tr_rpc_v2_call_id call,
                                  const struct tr_rpc_v2_request *request,
                                  const struct tr_rpc_v2_cancel *cancel,
                                  struct tr_rpc_v2_reply *reply, void *arg)
{
	if (request->kind != TR_RPC_V2_REQUEST_MESSAGE || request->body.len < 8U)
		return echo_v2_impl(call, request, cancel, reply, arg);
	unsigned index = atomic_fetch_add_explicit(&tr_unary_probe_count, 1U,
	                                           memory_order_relaxed);
	if (index >= 32768U)
		abort();
	struct tr_unary_probe_event *event = &tr_unary_probe_events[index];
	for (unsigned i = 0U; i < 8U; ++i)
		event->sequence |= (uint64_t)request->body.data[i] << (8U * i);
	event->begin_ns = now_ns();
	enum tr_rpc_status result = echo_v2_impl(call, request, cancel, reply, arg);
	event->end_ns = now_ns();
	event->status = result;
	return result;
}

static int run_server(const struct options *o)''')
replace('\tdestroy_server_retry(server);\n\treturn status', '''	destroy_server_retry(server);
	fprintf(stderr, "{\\"type\\":\\"unary_server_stage_probe\\",\\"events\\":[");
	for (unsigned i = 0U; i < atomic_load(&tr_unary_probe_count); ++i) {
		struct tr_unary_probe_event *event = &tr_unary_probe_events[i];
		fprintf(stderr, "%s[%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%d]",
		        i ? "," : "", event->sequence, event->begin_ns,
		        event->end_ns, event->status);
	}
	fprintf(stderr, "]}\\n");
	return status''')
begin=s.index('static void result_message(');end=s.index('static void result_terminal(',begin)
part=s[begin:end]
old='\t\tslot->message_seen = 1;';assert part.count(old)==1
part=part.replace(old,old+'\n\t\tslot->sample->probe_message_ns = now_ns();')
s=s[:begin]+part+s[end:]
replace('\tuint64_t probe_cpu_begin = probe_thread_cpu_ns();',
        '\tuint64_t probe_cpu_begin = probe_thread_cpu_ns();\n'
        '\tuint64_t probe_pid = (uint64_t)(uint32_t)getpid();')
replace('\t\tuint64_t sequence = i;',
        '\t\tuint64_t sequence = (probe_pid << 32U) | i;')
replace('"\\"scheduler_dropped\\"],\\"samples\\":[",',
        '"\\"scheduler_dropped\\",\\"message_callback_ns\\"],\\"samples\\":[",')
replace('\t\t        ",%" PRIu64 ",%" PRIu64 ",%d,%d]", sample ? "," : "",',
        '\t\t        ",%" PRIu64 ",%" PRIu64 ",%d,%d,%" PRIu64 "]", sample ? "," : "",')
replace('\t\t        s->submit_status, s->scheduler_dropped);',
        '\t\t        s->submit_status, s->scheduler_dropped, s->probe_message_ns);')
path.write_text(s)
meta=dict(base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
          source_path='bench/bench_rpc.c',
          original_sha256=hashlib.sha256(before).hexdigest(),
          instrumented_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
          patch=subprocess.check_output(['git','diff','--','bench/bench_rpc.c']).decode(),
          request_marker='高 32 位 PID / 低 32 位计划序号；仍为原 32 字节 RAW 正文')
(out/'probe.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
print(out)
