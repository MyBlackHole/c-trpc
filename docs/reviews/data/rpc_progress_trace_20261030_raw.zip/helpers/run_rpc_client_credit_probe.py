"""以原重复性入口运行临时 CONTROL TX 诊断，保留全部样本。"""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path.cwd()
out = root/'build/performance-20261029/rpc-client-credit-probe-v182'
meta = json.loads((out/'probe.json').read_text())
binary = out/'bench_rpc.probe'
assert hashlib.sha256(binary.read_bytes()).hexdigest() == meta['binary_sha256']
env = dict(os.environ, TMPDIR=str(root/'build/test-tmp'),
           TMP=str(root/'build/test-tmp'), TEMP=str(root/'build/test-tmp'),
           XMAKE_TMPDIR=str(root/'build/test-tmp'), PYTHONDONTWRITEBYTECODE='1')
identity = root/'build/performance-20261029/tls-zstd-hour-3600s'
events = []
for mode in ('plain',):
    destination = out/f'{mode}.jsonl'
    assert not destination.exists()
    command = [sys.executable, str(root/'bench/run_rpc_repeatability.py'),
               '--binary', str(binary), '--output', str(destination),
               '--label', f'rpc-client-credit-probe-{mode}', '--trials', '1',
               '--rate', '40000', '--min-arrival-ms', '250']
    if mode == 'tls-zstd':
        command += ['--tls', '--compression', 'zstd',
                    '--tls-ca', str(identity/'ca.pem'),
                    '--tls-cert', str(identity/'server.pem'),
                    '--tls-key', str(identity/'server.key')]
    start = time.monotonic()
    with destination.with_suffix('.log').open('w') as log:
        result = subprocess.run(command, cwd=root, env=env,
                                stdout=log, stderr=subprocess.STDOUT,
                                timeout=600)
    events.append(dict(mode=mode, command=command, exit_code=result.returncode,
                       elapsed_s=time.monotonic()-start))
    (out/'execution.json').write_text(json.dumps(events,indent=2)+'\n')
    print(f'{mode}: exit={result.returncode}', flush=True)
    if result.returncode:
        raise RuntimeError(str(destination.with_suffix('.log')))
