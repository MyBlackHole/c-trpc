"""临时关联 unary 的 owner 接管、传输信用与 Record 接受时刻。"""
from pathlib import Path
import hashlib,json,subprocess
root=Path.cwd();out=root/'build/performance-20261029/rpc-client-credit-probe-v182'
out.mkdir(exist_ok=False)
files={}
for name in ('bench/bench_rpc.c','src/rpc/rpc_record_client.c'):
    before=(root/name).read_bytes()
    (out/(Path(name).name+'.original')).write_bytes(before)
    files[name]={'original_sha256':hashlib.sha256(before).hexdigest()}
previous=json.loads((root/'build/performance-20261029/rpc-unary-stage-probe-v182/probe.json').read_text())
assert files['bench/bench_rpc.c']['original_sha256']==previous['original_sha256']
subprocess.run(['git','apply','--check','-'],input=previous['patch'].encode(),check=True)
subprocess.run(['git','apply','-'],input=previous['patch'].encode(),check=True)
path=root/'src/rpc/rpc_record_client.c';s=path.read_text()
def replace(old,new,count=1):
    global s
    assert s.count(old)==count,(old[:70],s.count(old))
    s=s.replace(old,new)
replace('#include <stdbool.h>','#include <stdbool.h>\n#include <stdio.h>\n#include <inttypes.h>')
replace('struct tr_record_client_slot {','''struct tr_client_credit_probe_event {
	uint64_t id, time_ns;
	unsigned stage;
};
static struct tr_client_credit_probe_event tr_client_credit_events[32768];
static unsigned tr_client_credit_event_count;
static void tr_client_credit_note(uint64_t id, unsigned stage)
{
	if (!id)
		return;
	if (tr_client_credit_event_count == 32768U)
		abort();
	struct timespec value;
	if (clock_gettime(CLOCK_MONOTONIC, &value) != 0)
		abort();
	struct tr_client_credit_probe_event *event =
	        &tr_client_credit_events[tr_client_credit_event_count++];
	event->id = id;
	event->time_ns = (uint64_t)value.tv_sec * UINT64_C(1000000000) +
	                 (uint64_t)value.tv_nsec;
	event->stage = stage;
}
struct tr_record_client_slot {
	uint64_t probe_id;''')
replace('\tslot->unary_body = copy;', '''	slot->unary_body = copy;
	if (unary_request && unary_request->len >= 8U) {
		for (unsigned i = 0U; i < 8U; ++i)
			slot->probe_id |= (uint64_t)unary_request->data[i] << (8U * i);
	}
	tr_client_credit_note(slot->probe_id, 1U);''')
replace('\tslot->routed = true;',
        '\ttr_client_credit_note(slot->probe_id, 2U);\n\tslot->routed = true;')
replace('\tif (event == TR_STREAM_EVENT_OPENED && !slot->peer_window_known) {',
        '\tif (event == TR_STREAM_EVENT_OPENED && !slot->peer_window_known) {\n'
        '\t\ttr_client_credit_note(slot->probe_id, 3U);')
replace('\t--slot->sending;\n\ttr_record_client_apply_pending(slot);',
        '\t--slot->sending;\n\tif (ret == TR_OK)\n'
        '\t\ttr_client_credit_note(slot->probe_id, 10U + header->kind);\n'
        '\ttr_record_client_apply_pending(slot);')
replace('\tif (slot->binding != binding || !slot->accepted)\n\t\treturn;',
        '\tif (slot->binding != binding || !slot->accepted)\n\t\treturn;\n'
        '\ttr_client_credit_note(slot->probe_id, 100U + view->header.kind);')
replace('\tsize_t bytes = client->bytes;\n\tfree(client);','''	size_t bytes = client->bytes;
	fprintf(stderr, "{\\"type\\":\\"client_credit_stage_probe\\",\\"events\\":[");
	for (unsigned i = 0U; i < tr_client_credit_event_count; ++i) {
		struct tr_client_credit_probe_event *event = &tr_client_credit_events[i];
		fprintf(stderr, "%s[%" PRIu64 ",%u,%" PRIu64 "]", i ? "," : "",
		        event->id, event->stage, event->time_ns);
	}
	fprintf(stderr, "]}\\n");
	free(client);''')
path.write_text(s)
for name,value in files.items():
    value['instrumented_sha256']=hashlib.sha256((root/name).read_bytes()).hexdigest()
meta=dict(base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),files=files,
          patch=subprocess.check_output(['git','diff','--',*files]).decode(),
          stages={'1':'owner 开始准备 unary','2':'传输 OPEN 已接受','3':'初始信用 OPENED',
                  '11':'Record OPEN 已接受','13':'请求 MESSAGE 已接受','14':'HALF_CLOSE 已接受',
                  '102':'响应 INITIAL','103':'响应 MESSAGE','105':'响应 FINAL'})
(out/'probe.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
print(out)
