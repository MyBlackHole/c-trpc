"""临时对齐信用、发送系统调用和对端完整帧派发的时间。"""
from pathlib import Path
import hashlib,json,subprocess
root=Path.cwd();out=root/'build/performance-20261029/rpc-frame-path-probe-v182'
out.mkdir(exist_ok=False)
paths=('bench/bench_rpc.c','src/rpc/rpc_record_client.c','src/execution/reactor.c')
files={}
for name in paths:
    before=(root/name).read_bytes()
    (out/(Path(name).name+'.original')).write_bytes(before)
    files[name]={'original_sha256':hashlib.sha256(before).hexdigest()}
old=json.loads((root/'build/performance-20261029/rpc-client-credit-probe-v182/probe.json').read_text())
for name,m in old['files'].items():assert files[name]['original_sha256']==m['original_sha256']
subprocess.run(['git','apply','--check','-'],input=old['patch'].encode(),check=True)
subprocess.run(['git','apply','-'],input=old['patch'].encode(),check=True)
def replace(s,old,new,count=1):
    assert s.count(old)==count,(old[:70],s.count(old))
    return s.replace(old,new)
path=root/'src/rpc/rpc_record_client.c';s=path.read_text()
s=replace(s,'static unsigned tr_client_credit_event_count;','''static unsigned tr_client_credit_event_count;
static struct { uint64_t id; uint32_t stream; } tr_client_credit_map[8192];
static unsigned tr_client_credit_map_count;''')
s=replace(s,'\ttr_client_credit_note(slot->probe_id, 2U);','''	tr_client_credit_note(slot->probe_id, 2U);
	if (slot->probe_id) {
		struct tr_stream_diagnostics diagnostic;
		if (tr_client_credit_map_count == 8192U ||
		    tr_stream_get_diagnostics(slot->stream, &diagnostic) != TR_OK)
			abort();
		tr_client_credit_map[tr_client_credit_map_count].id = slot->probe_id;
		tr_client_credit_map[tr_client_credit_map_count++].stream = diagnostic.stream_id;
	}''')
s=replace(s,'\tfprintf(stderr, "]}\\n");','''	fprintf(stderr, "],\\"stream_map\\":[");
	for (unsigned i = 0U; i < tr_client_credit_map_count; ++i)
		fprintf(stderr, "%s[%" PRIu64 ",%u]", i ? "," : "",
		        tr_client_credit_map[i].id, tr_client_credit_map[i].stream);
	fprintf(stderr, "]}\\n");''')
path.write_text(s)
path=root/'src/execution/reactor.c';s=path.read_text()
s=replace(s,'#include <limits.h>','#include <limits.h>\n#include <stdio.h>\n#include <inttypes.h>\n#include <arpa/inet.h>\n#include <netinet/tcp.h>')
s=replace(s,'struct tr_connection {','''struct tr_frame_path_probe_event {
	uint64_t message, begin_ns, end_ns;
	uint32_t stream;
	uint16_t local, peer, direction, type;
	int nodelay;
};
static struct tr_frame_path_probe_event tr_frame_path_events[131072];
static atomic_uint tr_frame_path_count;
struct tr_connection {
	uint16_t probe_local, probe_peer;
	int probe_nodelay;''')
s=replace(s,'\tconnection->fd = fd;','''	connection->fd = fd;
	struct sockaddr_in probe_local = {0}, probe_peer = {0};
	socklen_t probe_len = sizeof(probe_local);
	socklen_t probe_option_len = sizeof(connection->probe_nodelay);
	if (getsockname(fd, (struct sockaddr *)&probe_local, &probe_len) != 0 ||
	    probe_local.sin_family != AF_INET)
		abort();
	probe_len = sizeof(probe_peer);
	if (getpeername(fd, (struct sockaddr *)&probe_peer, &probe_len) != 0 ||
	    getsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &connection->probe_nodelay,
	               &probe_option_len) != 0)
		abort();
	connection->probe_local = ntohs(probe_local.sin_port);
	connection->probe_peer = ntohs(probe_peer.sin_port);''')
s=replace(s,'static void tr_connection_flush_tx(struct tr_reactor *reactor,','''static void tr_frame_path_note(struct tr_connection *connection, uint16_t direction,
                               uint16_t type, uint32_t stream, uint64_t message,
                               uint64_t begin_ns)
{
	if (type != TR_FRAME_DATA && type != TR_FRAME_STREAM_OPEN &&
	    type != TR_FRAME_WINDOW_UPDATE)
		return;
	unsigned index = atomic_fetch_add_explicit(&tr_frame_path_count, 1U,
	                                           memory_order_relaxed);
	if (index == 131072U)
		abort();
	struct tr_frame_path_probe_event *event = &tr_frame_path_events[index];
	event->local = connection->probe_local;
	event->peer = connection->probe_peer;
	event->nodelay = connection->probe_nodelay;
	event->direction = direction;
	event->type = type;
	event->stream = stream;
	event->message = message;
	event->end_ns = tr_reactor_now_ns();
	event->begin_ns = begin_ns ? begin_ns : event->end_ns;
}

static void tr_connection_flush_tx(struct tr_reactor *reactor,''')
s=replace(s,'\t\tint iov_count;\n','\t\tint iov_count;\n\t\tuint64_t probe_send_begin;\n')
s=replace(s,'\t\tif (connection->byte_endpoint) {\n\t\t\tconst void *write_buffer;',
            '\t\tprobe_send_begin = tr_reactor_now_ns();\n\t\tif (connection->byte_endpoint) {\n\t\t\tconst void *write_buffer;')
s=replace(s,'\t\t\tif (item->wire_pos == item->wire_len) {', '''			if (item->wire_pos == item->wire_len) {
				tr_frame_path_note(connection, 2U, item->type,
				                   item->stream_id, item->message_id,
				                   probe_send_begin);''')
s=replace(s,'\tif (connection->frame_cb)\n', '''	tr_frame_path_note(connection, 1U, frame->header.type,
	                   frame->header.stream_id, frame->header.message_id, 0U);
	if (connection->frame_cb)
''')
s=replace(s,'\ttr_tx_pool_destroy(&reactor->control_tx_pool);\n\ttr_tx_pool_destroy(&reactor->tx_pool);','''	fprintf(stderr, "{\\"type\\":\\"reactor_frame_path_probe\\",\\"events\\":[");
	for (unsigned i = 0U; i < atomic_load(&tr_frame_path_count); ++i) {
		struct tr_frame_path_probe_event *event = &tr_frame_path_events[i];
		fprintf(stderr, "%s[%u,%u,%u,%u,%u,%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%d]",
		        i ? "," : "", event->local, event->peer, event->direction,
		        event->type, event->stream, event->message,
		        event->begin_ns, event->end_ns, event->nodelay);
	}
	fprintf(stderr, "]}\\n");
	tr_tx_pool_destroy(&reactor->control_tx_pool);
	tr_tx_pool_destroy(&reactor->tx_pool);''')
path.write_text(s)
for name,value in files.items():value['instrumented_sha256']=hashlib.sha256((root/name).read_bytes()).hexdigest()
meta=dict(base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),files=files,
          patch=subprocess.check_output(['git','diff','--',*paths]).decode(),
          frame_columns=['local_port','peer_port','direction_rx1_tx2','frame_type','stream_id','message_id','send_begin_or_rx_ns','send_end_or_rx_ns','tcp_nodelay'])
(out/'probe.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
print(out)
