"""临时统计 Endpoint 进度 CPU、Dispatch 扫描和真实任务阶段等待。"""
from pathlib import Path
import hashlib,json,subprocess
root=Path.cwd()
out=root/'build/performance-20261029/rpc-progress-cpu-probe-v182'
out.mkdir(exist_ok=False)
sources={}
def sha(b):return hashlib.sha256(b).hexdigest()
def edit(path,transform):
    before=(root/path).read_bytes()
    (out/(Path(path).name+'.original')).write_bytes(before)
    after=transform(before.decode()).encode()
    (root/path).write_bytes(after)
    sources[path]=dict(original_sha256=sha(before),instrumented_sha256=sha(after))
def replace(s,old,new,count=1):
    assert s.count(old)==count,(old[:60],s.count(old))
    return s.replace(old,new)
def endpoint(s):
    s=replace(s,'#include <stdatomic.h>','#include <stdatomic.h>\n#include <stdio.h>\n#include <inttypes.h>')
    s=replace(s,'struct tr_rpc_record_endpoint {','''static uint64_t tr_progress_probe_clock(clockid_t clock)
{
	struct timespec value;
	if (clock_gettime(clock, &value) != 0)
		abort();
	return (uint64_t)value.tv_sec * UINT64_C(1000000000) +
	       (uint64_t)value.tv_nsec;
}
struct tr_rpc_record_endpoint {
	uint64_t probe_calls, probe_cpu, probe_wall, probe_max_wall;''')
    begin=s.index('int tr_rpc_record_endpoint_pump_on_owner(')
    end=s.index('static uint64_t tr_endpoint_tick',begin)
    part=s[begin:end]
    part=replace(part,'\t++ep->depth;','''	uint64_t probe_cpu = tr_progress_probe_clock(CLOCK_THREAD_CPUTIME_ID);
	uint64_t probe_wall = tr_progress_probe_clock(CLOCK_MONOTONIC);
	++ep->depth;''')
    part=replace(part,'out:\n\t--ep->depth;','''out:
	--ep->depth;
	probe_cpu = tr_progress_probe_clock(CLOCK_THREAD_CPUTIME_ID) - probe_cpu;
	probe_wall = tr_progress_probe_clock(CLOCK_MONOTONIC) - probe_wall;
	ep->probe_calls++;
	ep->probe_cpu += probe_cpu;
	ep->probe_wall += probe_wall;
	if (probe_wall > ep->probe_max_wall)
		ep->probe_max_wall = probe_wall;''')
    s=s[:begin]+part+s[end:]
    s=replace(s,'\ttr_endpoint_frames_put(ep->frames);\n\tfree(ep);','''	tr_endpoint_frames_put(ep->frames);
	fprintf(stderr, "{\\"type\\":\\"endpoint_cpu_probe\\",\\"capacity\\":%zu,"
	        "\\"calls\\":%" PRIu64 ",\\"cpu_ns\\":%" PRIu64
	        ",\\"wall_sum_ns\\":%" PRIu64 ",\\"wall_max_ns\\":%" PRIu64 "}\\n",
	        ep->capacity, ep->probe_calls, ep->probe_cpu,
	        ep->probe_wall, ep->probe_max_wall);
	free(ep);''')
    return s
def dispatch(s):
    s=replace(s,'#include <stdlib.h>','#include <stdlib.h>\n#include <stdio.h>\n#include <inttypes.h>')
    s=replace(s,'struct tr_dispatch_job {','''static uint64_t tr_dispatch_probe_now(void)
{
	struct timespec value;
	if (clock_gettime(CLOCK_MONOTONIC, &value) != 0)
		abort();
	return (uint64_t)value.tv_sec * UINT64_C(1000000000) +
	       (uint64_t)value.tv_nsec;
}
static void tr_dispatch_probe_observe(uint64_t hist[34], uint64_t value)
{
	unsigned bucket = 0U;
	uint64_t bound = 1000U;
	while (value > bound && bucket < 31U) {
		bound <<= 1U;
		bucket++;
	}
	hist[bucket]++;
	hist[32] += value;
	if (value > hist[33])
		hist[33] = value;
}
struct tr_dispatch_job {
	uint64_t probe_submit, probe_begin, probe_end;''')
    s=replace(s,'struct tr_rpc_record_dispatch {','''struct tr_rpc_record_dispatch {
	uint64_t probe_pumps, probe_visits, probe_active;
	uint64_t probe_queue[34], probe_work[34], probe_delivery[34];''')
    s=replace(s,'static int tr_dispatch_work(void *arg, const struct tr_task_cancel *cancel)',
              'static int tr_dispatch_work_impl(void *arg, const struct tr_task_cancel *cancel)')
    s=replace(s,'static void tr_dispatch_done(void *arg, struct tr_task_handle handle,','''static int tr_dispatch_work(void *arg, const struct tr_task_cancel *cancel)
{
	struct tr_dispatch_job *job = arg;
	job->probe_begin = tr_dispatch_probe_now();
	int ret = tr_dispatch_work_impl(arg, cancel);
	job->probe_end = tr_dispatch_probe_now();
	return ret;
}
static void tr_dispatch_done(void *arg, struct tr_task_handle handle,''')
    s=replace(s,'\tbool acquired = job->reply.producer != NULL;','''	bool acquired = job->reply.producer != NULL;
	if (job->probe_begin && job->probe_end) {
		tr_dispatch_probe_observe(d->probe_queue, job->probe_begin - job->probe_submit);
		tr_dispatch_probe_observe(d->probe_work, job->probe_end - job->probe_begin);
		tr_dispatch_probe_observe(d->probe_delivery, tr_dispatch_probe_now() - job->probe_end);
	}''')
    s=replace(s,'\tret = tr_task_executor_submit(d->executor, &spec, &s->task);',
              '\tjob->probe_submit = tr_dispatch_probe_now();\n\tret = tr_task_executor_submit(d->executor, &spec, &s->task);')
    begin=s.index('int tr_rpc_record_dispatch_pump_on_owner(')
    end=s.index('int tr_rpc_record_dispatch_abort_on_owner(',begin)
    part=s[begin:end]
    part=replace(part,'\twhile (limit--) {','\td->probe_pumps++;\n\twhile (limit--) {\n\t\td->probe_visits++;')
    part=replace(part,'\t\tif (s->active)\n\t\t\ttr_dispatch_step(s);','\t\tif (s->active) {\n\t\t\td->probe_active++;\n\t\t\ttr_dispatch_step(s);\n\t\t}')
    s=s[:begin]+part+s[end:]
    begin=s.index('static int tr_dispatch_free(')
    tail=s[begin:]
    tail=replace(tail,'\tfree(d);','''	fprintf(stderr, "{\\"type\\":\\"dispatch_progress_probe\\",\\"capacity\\":%u,"
	        "\\"pumps\\":%" PRIu64 ",\\"visits\\":%" PRIu64 ",\\"active\\":%" PRIu64
	        ",\\"hist_queue_work_delivery\\":[", d->config.capacity,
	        d->probe_pumps, d->probe_visits, d->probe_active);
	uint64_t *probe_histograms[] = {d->probe_queue, d->probe_work, d->probe_delivery};
	for (unsigned i = 0U; i < 3U; ++i) {
		fprintf(stderr, "%s[", i ? "," : "");
		for (unsigned j = 0U; j < 34U; ++j)
			fprintf(stderr, "%s%" PRIu64, j ? "," : "", probe_histograms[i][j]);
		fprintf(stderr, "]");
	}
	fprintf(stderr, "]}\\n");
	free(d);''')
    return s[:begin]+tail
edit('src/rpc/rpc_record_endpoint.c',endpoint)
edit('src/rpc/rpc_record_dispatch.c',dispatch)
meta=dict(base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
          files=sources,patch=subprocess.check_output(['git','diff','--','src/rpc/rpc_record_endpoint.c','src/rpc/rpc_record_dispatch.c']).decode())
(out/'probe.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
print(out)
