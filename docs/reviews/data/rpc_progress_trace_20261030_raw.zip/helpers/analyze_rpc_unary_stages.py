"""从原始 PID/序号关联三段业务时间，保持原干净样本判定。"""
from pathlib import Path
import json,math
out=Path('build/performance-20261029/rpc-unary-stage-probe-v182')
summary=[]
def percentile(values,p):
    ordered=sorted(values)
    return ordered[max(0,math.ceil(len(ordered)*p)-1)]/1e6 if ordered else None
for case in map(json.loads,(out/'plain.jsonl').read_text().splitlines()):
    if case['type']!='repeatability_case':
        continue
    directory=out/'plain-logs'/f"t1-{case['public_profile']}-40000rps"
    server=json.loads((directory/'server.stderr').read_text())
    assert server['type']=='unary_server_stage_probe'
    events={}
    warm=0
    for sequence,begin,end,status in server['events']:
        assert end>=begin
        if sequence>>32==0:
            warm+=1
            continue
        assert sequence not in events
        events[sequence]=(begin,end,status)
    stages={k:[] for k in ('pre_work','work','post_work_to_message',
                           'message_to_terminal','total')}
    matched=0;accepted=0;missing_work=0;missing_response=0;all_keys=set()
    for generator in range(16):
        original=json.loads((directory/f'client-{generator}.jsonl').read_text())
        probe=json.loads((directory/f'client-{generator}.stderr').read_text())
        assert len(probe['samples'])==original['offered']==625
        for index,sample in enumerate(probe['samples']):
            scheduled,woken,locked,submit,returned,terminal,status,dropped,message=sample
            sequence=(original['pid']<<32)|index
            all_keys.add(sequence)
            if dropped or status!=0:
                assert sequence not in events
                continue
            accepted+=1
            if sequence not in events:
                missing_work+=1
                continue
            begin,end,work_status=events[sequence]
            assert begin>=submit and end>=begin
            if message==0:
                missing_response+=1
                continue
            assert work_status==0 and terminal>=message>=end
            times=dict(pre_work=begin-submit,work=end-begin,
                       post_work_to_message=message-end,
                       message_to_terminal=terminal-message,
                       total=terminal-submit)
            assert sum(v for k,v in times.items() if k!='total')==times['total']
            for key,value in times.items():
                stages[key].append(value)
            matched+=1
    assert set(events)<=all_keys
    assert accepted==case['client']['accepted']
    assert matched==case['client']['ok']
    row=dict(profile=case['public_profile'],accepted=accepted,matched_ok=matched,
             missing_work=missing_work,missing_response=missing_response,
             warmup_messages=warm,dropped=case['client']['scheduler_dropped'],
             wall_signals=case['wall_signals'],
             stages={k:dict(p50_ms=percentile(values,.5),p99_ms=percentile(values,.99),
                            average_ms=sum(values)/len(values)/1e6,
                            sum_fraction_of_total=sum(values)/sum(stages['total']))
                     for k,values in stages.items()})
    summary.append(row)
    print(json.dumps(row))
assert len(summary)==3
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
