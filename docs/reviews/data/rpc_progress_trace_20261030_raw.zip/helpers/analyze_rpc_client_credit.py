"""重建客户端信用等待与服务端业务开始前的时间分段。"""
from pathlib import Path
import json,math
out=Path('build/performance-20261029/rpc-client-credit-probe-v182')
def percentile(values,p):
    values=sorted(values)
    return values[max(0,math.ceil(len(values)*p)-1)]/1e6 if values else None
summary=[]
for case in map(json.loads,(out/'plain.jsonl').read_text().splitlines()):
    if case['type']!='repeatability_case':continue
    directory=out/'plain-logs'/f"t1-{case['public_profile']}-40000rps"
    server=json.loads((directory/'server.stderr').read_text())
    work={event[0]:event[1:] for event in server['events'] if event[0]>>32}
    values={key:[] for key in ('api_to_owner','owner_to_transport_open',
            'initial_credit_wait','credit_to_rpc_open','rpc_open_to_message',
            'request_accepted_to_work','work','work_to_response',
            'response_to_final','total')}
    matched=0
    for generator in range(16):
        original=json.loads((directory/f'client-{generator}.jsonl').read_text())
        traces=list(map(json.loads,(directory/f'client-{generator}.stderr').read_text().splitlines()))
        probe=next(r for r in traces if r['type']=='rpc_admission_probe')
        credit=next(r for r in traces if r['type']=='client_credit_stage_probe')
        events={}
        for sequence,stage,time in credit['events']:
            if not sequence>>32:continue
            stages=events.setdefault(sequence,{})
            assert stage not in stages,(sequence,stage)
            stages[stage]=time
        for index,sample in enumerate(probe['samples']):
            scheduled,wake,lock,submit,returned,terminal,status,dropped,response=sample
            if not response:continue
            sequence=(original['pid']<<32)|index
            assert not dropped and status==0 and sequence in work and sequence in events
            stages=events[sequence]
            assert all(stage in stages for stage in (1,2,3,11,13,14,103,105))
            begin,end,work_status=work[sequence];assert work_status==0
            times=(submit,stages[1],stages[2],stages[3],stages[11],stages[13],begin,end,response,terminal)
            assert all(a<=b for a,b in zip(times,times[1:])),times
            assert stages[13]<=stages[14] and stages[103]<=response<=stages[105]<=terminal
            for key,(a,b) in zip(list(values)[:-1],zip(times,times[1:])):
                values[key].append(b-a)
            values['total'].append(terminal-submit)
            matched+=1
    assert matched==case['client']['ok']
    row=dict(profile=case['public_profile'],matched_ok=matched,
             accepted=case['client']['accepted'],dropped=case['client']['scheduler_dropped'],
             wall_signals=case['wall_signals'],stages={key:dict(
                 p50_ms=percentile(data,.5),p99_ms=percentile(data,.99),
                 average_ms=sum(data)/len(data)/1e6,
                 sum_fraction_of_total=sum(data)/sum(values['total']))
                 for key,data in values.items()})
    summary.append(row);print(json.dumps(row))
assert len(summary)==3
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
