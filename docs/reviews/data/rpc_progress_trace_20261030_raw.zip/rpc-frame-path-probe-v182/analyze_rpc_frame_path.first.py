"""关联固定明文场景的端口、wire stream 与 unary 标识。"""
from pathlib import Path
import json,math
out=Path('build/performance-20261029/rpc-frame-path-probe-v182')
def pick(rows,kind):
    matching=[r for r in rows if r['type']==kind]
    assert len(matching)==1,(kind,len(matching))
    return matching[0]
def percentile(values,p):
    values=sorted(values)
    return values[max(0,math.ceil(len(values)*p)-1)]/1e6
def frame(events,local,peer,direction,kind,stream,message=None):
    matching=[e for e in events if e[:5]==[local,peer,direction,kind,stream]
              and (message is None or e[5]==message)]
    assert len(matching)==1,(local,peer,direction,kind,stream,message,len(matching))
    return matching[0]
summary=[]
for case in map(json.loads,(out/'plain.jsonl').read_text().splitlines()):
    if case['type']!='repeatability_case':continue
    directory=out/'plain-logs'/f"t1-{case['public_profile']}-40000rps"
    server_rows=list(map(json.loads,(directory/'server.stderr').read_text().splitlines()))
    server=pick(server_rows,'unary_server_stage_probe')
    server_frames=pick(server_rows,'reactor_frame_path_probe')['events']
    work={r[0]:r[1:] for r in server['events'] if r[0]>>32}
    names=('api_to_transport_open','client_open_queue','open_tx_to_server_rx',
           'server_credit_queue','credit_tx_to_client_rx','client_credit_dispatch',
           'credit_to_request_accepted','client_request_queue','request_tx_to_server_rx',
           'server_request_rx_to_work','work','work_to_response','response_to_terminal','total')
    values={k:[] for k in names};matched=0;nodelay=set();negative_full_send_end=0
    for generator in range(16):
        original=json.loads((directory/f'client-{generator}.jsonl').read_text())
        rows=list(map(json.loads,(directory/f'client-{generator}.stderr').read_text().splitlines()))
        admission=pick(rows,'rpc_admission_probe')
        credit=pick(rows,'client_credit_stage_probe')
        frames=pick(rows,'reactor_frame_path_probe')['events']
        pairs={(r[0],r[1]) for r in frames if r[2:4]==[2,2]}
        assert len(pairs)==1
        local,peer=next(iter(pairs));mapping=dict(credit['stream_map'])
        events={}
        for sequence,stage,time in credit['events']:
            events.setdefault(sequence,{})[stage]=time
        nodelay.update(r[8] for r in frames+server_frames)
        for index,sample in enumerate(admission['samples']):
            scheduled,wake,lock,submit,returned,terminal,status,dropped,response=sample
            if not response:continue
            sequence=(original['pid']<<32)|index;stream=mapping[sequence]
            stages=events[sequence];begin,end,work_status=work[sequence]
            assert status==work_status==0 and not dropped
            c_open=frame(frames,local,peer,2,2,stream)
            s_open=frame(server_frames,peer,local,1,2,stream)
            s_credit=frame(server_frames,peer,local,2,4,stream)
            c_credit=frame(frames,local,peer,1,4,stream)
            c_request=frame(frames,local,peer,2,1,stream,2)
            s_request=frame(server_frames,peer,local,1,1,stream,2)
            times=(submit,stages[2],c_open[6],s_open[6],s_credit[6],c_credit[6],
                   stages[3],stages[13],c_request[6],s_request[6],begin,end,response,terminal)
            assert all(a<=b for a,b in zip(times,times[1:])),times
            for sender,receiver in ((c_open,s_open),(s_credit,c_credit),(c_request,s_request)):
                negative_full_send_end+=receiver[6]<sender[7]
            for key,(a,b) in zip(names[:-1],zip(times,times[1:])):
                values[key].append(b-a)
            values['total'].append(terminal-submit);matched+=1
    assert matched==case['client']['ok'] and nodelay=={1}
    row=dict(profile=case['public_profile'],matched_ok=matched,
             accepted=case['client']['accepted'],dropped=case['client']['scheduler_dropped'],
             tcp_nodelay=list(nodelay),receiver_before_sender_return=negative_full_send_end,
             stages={key:dict(p50_ms=percentile(data,.5),p99_ms=percentile(data,.99),
               average_ms=sum(data)/len(data)/1e6,
               sum_fraction_of_total=sum(data)/sum(values['total']))
               for key,data in values.items()})
    summary.append(row);print(json.dumps(row))
assert len(summary)==3
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
