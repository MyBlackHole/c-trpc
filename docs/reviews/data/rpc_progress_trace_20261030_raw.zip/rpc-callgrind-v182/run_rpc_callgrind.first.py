"""用原 Xmake ELF 对单 Server owner 做指令路径诊断，不作性能验收。"""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path.cwd();out=root/'build/performance-20261029/rpc-callgrind-v182'
out.mkdir(exist_ok=False)
binary=root/'build/linux/x86_64/release/bench_rpc'
expected='55d1c4b990f1878f7999017960c2c6cf5443fdf998be9ece389c5fa946bd137e'
assert hashlib.sha256(binary.read_bytes()).hexdigest()==expected
sys.path.insert(0,str(root/'bench'))
from run_rpc_bench import read_ready,stop_owned,validate_server_exit,validate_phase
env=dict(os.environ,TMPDIR=str(root/'build/test-tmp'),TMP=str(root/'build/test-tmp'),
         TEMP=str(root/'build/test-tmp'),XMAKE_TMPDIR=str(root/'build/test-tmp'),
         PYTHONDONTWRITEBYTECODE='1',DEBUGINFOD_URLS='')
server_command=['valgrind','--tool=callgrind','--vgdb=no',
                '--vgdb-prefix='+str(out/'vgdb'),
                '--enable-debuginfod=no','--collect-atstart=no',
                '--toggle-collect=tr_reactor_thread_main','--separate-threads=yes',
                '--callgrind-out-file='+str(out/'callgrind.%p'),
                '--log-file='+str(out/'valgrind.%p.log'),
                str(binary),'server','--capacity','128','--bulk-bytes','65536',
                '--slow-ms','0','--tls','0','--compression','none']
manifest=dict(base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
              binary_sha256=expected,server_command=server_command,
              note='单 Client/64 window/256 measure/32 warmup；只收集 Server owner 指令，不作 40k 或延迟结论')
(out/'execution.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
server=None;client=None
start=time.monotonic()
try:
    with (out/'server.stderr').open('w') as errors:
        server=subprocess.Popen(server_command,stdin=subprocess.PIPE,stdout=subprocess.PIPE,
                                stderr=errors,text=True,env=env,cwd=root)
        ready=read_ready(server,'ready',timeout=60)
        print(f'profile server ready pid={server.pid}',flush=True)
        client_command=[str(binary),'client','--capacity','128','--bulk-bytes','65536',
                        '--port',str(ready['port']),'--window','64','--scenario','small',
                        '--requests','256','--warmup','32','--timeout-ms','30000',
                        '--tls','0','--compression','none']
        manifest['client_command']=client_command
        with (out/'client.stderr').open('w') as client_errors:
            client=subprocess.Popen(client_command,stdout=subprocess.PIPE,stderr=client_errors,
                                    text=True,env=env,cwd=root)
            client_stdout,_=client.communicate(timeout=180)
        (out/'client.jsonl').write_text(client_stdout)
        manifest['client_exit_code']=client.returncode
        assert client.returncode==0
        rows=list(map(json.loads,client_stdout.splitlines()))
        assert len(rows)==1
        validate_phase(rows[0],256,'small',64)
        stdout,_=server.communicate(timeout=60)
        (out/'server.jsonl').write_text(json.dumps(ready)+'\n'+stdout)
        manifest['server_exit_code']=server.returncode
        assert server.returncode==0
        final=json.loads(stdout);validate_server_exit(final)
        assert final['rpc_calls_started']==final['rpc_calls_finished']==288
        print('profile workload: 256 measured + 32 warmup drained',flush=True)
finally:
    for child in (client,server):
        if child is not None:stop_owned(child)
    manifest['elapsed_s']=time.monotonic()-start
    (out/'execution.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
